
//import custom module 
const comp  = require('./mymodule/Compute');
const DB = require('./mymodule/DBAction');

console.log(typeof comp.add)
console.log(typeof comp.sub)
console.log(typeof comp.tax)


console.log(typeof comp.div) //undefined 



DB.getdata();
DB.savedata();
DB.getdata();



