
import React,{Component} from 'react';

class Product extends Component{

    constructor(){

        super();
        
        this.state ={

                data:[]
        }  //constructor init the object 

    }
    //create function 
    addProduct=()=>{

            //alert('hey , you have clicked on button');

            var name = this.refs.pname.value;
            var pp = this.refs.pprice.value;
            var pq = this.refs.pqty.value;

            //
            var prod = this.state.data;
            prod.push({pname:name,pprice:pp,pqty:pq});


            //update state (now store data to state)
            this.setState({data:prod});

            console.log(this.state.data);

            //console.log('you have entered ',name,pp,pq);

            ///
            this.clr();    
    }

    clr=()=>{

            ///clear the form 
            this.refs.pname.value="";
            this.refs.pprice.value="";
            this.refs.pqty.value="";
    }
        render(){

                return(<div>
                    
                        <h2> Product Section </h2>
                        <p>
                          Product Name  <input type="text" ref="pname" />
                        </p>
                        <p>
                          Product Price  <input type="text"  ref="pprice"/>
                        </p>
                        <p>
                          Proeuct Quantity  <input type="text" ref="pqty" />
                        </p>
                        <p>
                            <input type="button" value="Clear" onClick={this.clr} />
                            <input type="button" value="Add Product" onClick={this.addProduct} />

                        </p>
                    </div>
                    )
        }

}

export default Product;
