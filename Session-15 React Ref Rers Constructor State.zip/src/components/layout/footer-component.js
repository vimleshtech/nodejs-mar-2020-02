
import React,{Component} from 'react';

class Footer extends Component{

        constructor(){
            super();   
        }

        render(){

                return(<div>
                    
                        <h2> All copy rights reserved .... @2020 </h2>
                    </div>
                    )
        }

}

export default Footer;
