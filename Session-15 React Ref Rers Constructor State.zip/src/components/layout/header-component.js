
import React,{Component} from 'react';

class Header extends Component{

        constructor(){
            super();   
        }

        render(){

                return(<div>
                    
                        <h2> Header - Section </h2>
                    </div>
                    )
        }

}

export default Header;
