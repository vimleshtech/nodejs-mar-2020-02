//import library 
// till ES5 : require
// ES>5     : import 

import React from 'react';

import Header from './components/layout/header-component';
import Footer from './components/layout/footer-component';
import Product from './components/module/product-component';


//extends : inherit the one class features to another class 
class   App extends React.Component{           //is wrapper of data member and method/function 

  render(){

    return(<div>
      
            <Header/>
            <Product/>
            <Footer/>
      </div>)
  }
}

//export 
export default App;

