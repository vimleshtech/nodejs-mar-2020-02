


function add(a,b){

    c =a+b 
    console.log(c)
}


function mul(a,b){
    
        c =a*b 
        console.log(c)
    }


    function series(s,n){
        
            for(let i=s; i<n; i++)
                console.log(i)
        }


//call to function 
add(44,66)
add(44,66)
add(44,6)
series(1000,10000)

        
    