
i =1  // init 
while(i<10) { //condition 

    console.log(i)
    i++;
}

//table of two 
i =1  // init 
while(i<=10) { //condition 

    console.log(i*2)
    i++;
}

//print in reverse 
i =10  // init 
while(i>0) { //condition 

    console.log(i)
    i--;
}


//FOR LOOP 
for(i=1; i<10; i++){
    console.log(i);
}


////
data = [111,3,5,6,7,43,3,6,7,4,4,7787,55.44,66,7,78,84444]
s  = 0
for(let ind=0; ind<data.length; ind++){
        s+= data[ind]
}   

console.log('sum = ',s)


