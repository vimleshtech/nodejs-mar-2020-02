
//example : 1
a =552
//check even and odd number

if(a%2 ==0){
    console.log('even number')
}else{

    console.log('odd number')
}

//wap to show which number is greater from three input
a =44400
b =66000
c =666 
if(a>b ){
    
    if(a>c){
        console.log('a is gt')
    }else{
        console.log('c is gt ')
    }

}else{

    
    if(b>c){
        console.log('b is gt')
    }else{
        console.log('c is gt ')
    }
}
// or 
/*
&& - AND
T T  =T
T F  =F
F T  =F
F F  =F

||   - OR
T T  =T
T F  =T
F T  =T
F F  =F

*/
if(a>b && a>c){
 console.log('a is gt')
}else if(b>a && b>c){
    console.log('b is gt')
}else{
    console.log('c is gt')
}





