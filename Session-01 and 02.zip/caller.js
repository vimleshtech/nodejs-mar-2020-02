

const cal = require('./cal')
//cosnt : read only 

function x(){

    var d =11 ; // global , or function , can be access within function 
    m =55 ; //global , m can be access outside from function
    

}
cal.add(11,344)
cal.mul(55,66)

