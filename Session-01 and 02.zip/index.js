const express = require('express'); 
const app = express();  // create an object of express() module / class


app.get('/home',(req,res)=>{

        res.json({code:400, msg:'test msg'})
})

app.listen(3010,()=>{ 
    
    console.log('test .... ')
    
    })



