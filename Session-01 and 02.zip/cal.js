module.exports ={

    
    add : function (a,b){
    
        c =a+b 
        console.log(c)
    },
    
    
    mul: function (a,b){
        
            c =a*b 
            console.log(c)
        },
        
}