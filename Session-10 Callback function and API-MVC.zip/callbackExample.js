
function add(a,b){
    
    console.log(a+b);
}

function sub(a,b){
    console.log(a-b);
}

function Controller(callback){ //callback is argument which take reference of function 
    callback(11,333);
}

//invoke to function 

Controller(sub); 
Controller(add); 

//Eexample -2 callback
function testCal(data,callback){
    data +=100;
    console.log(callback);
    callback(data); //return back to same function 
}

testCal(10,(res)=>{ console.log(res)});
//or call like this
testCal(10,function(out){console.log(out)});
