
student = [{Student_ID:01,Name:'Nitin',Gender:'male',Hindi:50,Math:50,Science:50,Eng:50,SST:50,Marks:50},
            {Student_ID:12,Name:'Vimlesh',Gender:'male',Hindi:45,Math:45,Science:45,Eng:45,SST:45,Marks:45},
            {Student_ID:13,Name:'Kapil',Gender:'male',Hindi:40,Math:40,Science:40,Eng:50,SST:40,Marks:40},
            {Student_ID:14,Name:'Monika',Gender:'male',Hindi:35,Math:35,Science:35,Eng:50,SST:35,Marks:35}]  

passing = student.filter(x=>x.Marks >= 40)


console.log(passing)



