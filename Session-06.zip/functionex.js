//no argument , no return
function welcome(){

    console.log('welcome to function world !!!')
    console.log('there are following mdodules in this function i. welcome ii. getdata, iii. add, iv. sub')
}
//no argument with return 
function getData(){
    
        var tax_pec = 18;

        return tax_pec;
    }

//function with argument and no return 
function add(a,b){
    var c = a+b
    console.log(c);    
    console.log(a);    
    console.log(b);    

}

//function with argument and with return 
function mul(x,y,z){

    m = x*t*z 
    return m 
}
//call  or invoke to function 
welcome() //call to welcome function 

t = getData() //call to getData function and recieve the value/result 
console.log(t)

//call to function with argument 
add(11,33)
add(55677,3333)


out = mul(11,33,556)
console.log(out*100)


//call to add function again 
add(out,100)



