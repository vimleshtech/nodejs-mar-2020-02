const fs = require('fs');
const DB = require('../mymodule/DBAction');

var data = fs.readFileSync("C:/Users/vkumar15/Desktop/learning/webserver/filemodule/sampledata.json");
//var data = fs.readFileSync("sampledata.json");

console.log(data)  //default data format is byte code 

let myjson = JSON.parse(data); //convert byte to json 
console.log(myjson);

//operation 
//console.log(myjson.name);
//console.log(myjson.country);

//get row count
console.log("no of rows "+myjson.length);

myjson.forEach(els => {
            console.log(els.id,els.name)
            DB.savedata(els.id,els.name)
});
