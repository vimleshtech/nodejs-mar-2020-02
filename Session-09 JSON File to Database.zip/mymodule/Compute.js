//Compute.js

//we need write: module.exports ={  //statement or to do }
module.exports ={

    add: function(x,y){
        var c =x+y;
        return c;
    },
    sub: function(a,b){
        var c = a-b;
        return c;

    },
    tax: function(amt){
            var t = 0;
            if(amt<250000){
                t = 0;
            }else if(amt<500000){
                t = (amt-250000)*.05;
            }else if(amt<1000000){
                t = 12500+ (amt-500000)*.20;
            }else {
                t = 112500+ (amt-1000000)*.30;
            }

            return t; 
    }
}

//cannot be exported (access in other file )

var div = function(a,b){
        return a/b;
        }
