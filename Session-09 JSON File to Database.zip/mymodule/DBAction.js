const mysql = require('mysql');

var con  = mysql.createConnection({

    host:'localhost',
    database:'db_webserver',
    user:'root',
    password:'root'
});

con.connect((err)=>{
                    if(err){
                                console.log('something went wrong! ',err);
                    }else{

                            console.log('db is connected !');
                    }
                }
)

module.exports ={

    savedata:function(eid,name){

            //"+eid+"
                //con.query("insert into users(id,name,email) values(10,'rahul','rahul@gmail.com')",(err,data)=>{
                    con.query("insert into users(id,name) values("+eid+",'"+name+"')",(err,data)=>{


                    if(err){
                        throw err;
                    }else{
                        console.log(data);
                    }
                });

    },
    getdata:function(){
        
                con.query("select * from users",(err,data)=>{

                    if(err){
                        throw err;
                    }else{
                        console.log(data);
                    }
                });

    },
    updatedata:function(){
        
    },
    deletedata:function(){
        
    }

}



