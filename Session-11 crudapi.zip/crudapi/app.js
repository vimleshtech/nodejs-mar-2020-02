
//import required module
const express = require("express");
const bodyParser = require("body-parser");

const router = require("./routes/route.module");

//initialize our express app
const app = express();

app.use(router);

//initialize the port
let port = 3010;
app.listen(port,()=>{

    console.log("Server is up and running on port number "+port);

});

