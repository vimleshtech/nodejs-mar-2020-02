const Customer = require("../models/customer.model");

//Simple version, without validation or sanitation 
exports.test = function(req,res){

        res.send('Greetings from the Customer Test controller!');
};
