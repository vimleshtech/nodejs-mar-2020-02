//const mongoose  = require("mongoose");
const mysql = require("mysql");
const Schema = mysql.Schema;


let SalesSchema = new Schema({

    customer:{type:String, required: true, max:100},
    product:{type:String, required: true, max:100},
    qty:{type:Number, required: true},
    price:{type:Number, required:true}
});

//export the model
module.exports = mysql.model('Sales',SalesSchema);


