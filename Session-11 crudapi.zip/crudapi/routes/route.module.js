const express = require("express");
const router = express.Router();


//Require the controllers which is created with sample code 
const product_controller = require("../controllers/product.controller");
const sales_controller = require("../controllers/sales.controller");
const customer_controller = require("../controllers/customer.controller");

router.get('product-view',product_controller.test);
router.get('customer-view',customer_controller.test);
router.get('sales-view',sales_controller.test);

module.exports = router;
