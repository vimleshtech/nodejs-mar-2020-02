var sales = [111,33,5,667,33,6663]

//print all data 
console.log(sales)

//print value by index
console.log(sales[0]) //first value
console.log(sales[2]) //3rd value

//print / length
console.log(sales.length) 

//add new value 
sales.push(9000)
sales.push(10)
console.log(sales)

//pop/remove from last
sales.pop()
console.log(sales)

//unshift: add at 0 index
sales.unshift(854)
console.log(sales)

//remove first value
sales.shift()
console.log(sales)

//remove values from object
sales.splice(3,2)  //(ind,count)
console.log(sales)


//sorting 
names =["nitin","aman","kapil","monika","amita"]
console.log(names)
names.sort()
console.log(names)

//reverse 
names =["nitin","aman","kapil","monika","amita"]
names.reverse()
console.log(names)

//in  descending 
names =["nitin","aman","kapil","monika","amita"]
console.log(names)
names.sort().reverse()
console.log(names)

// filter data 
console.log(sales)
out = sales.filter(y=> y > 1200 )
console.log(out)

out = sales.filter(y => y > 10 && y<1200 ) //between 
console.log(out)

//or [1,5,5]
//    0 1 2 
out = [] //empty object / array  
for(let i=0; i<sales.length;i++){
    if(sales[i]>10 && sales[i]<1200){
        out.push(sales[i])
    }
}
console.log(out)
//exact match 


//2 dimenssion object
a =[[11,33,5],[4,6,33]]
/*
11,33,5   00 01  02
4,6,33    10  11 12 
*/

console.log(a.length) //2 
console.log(a[0]) //print first row
console.log(a[0].length)

console.log(a[0][1]) //first row , and 2nd col 



//read all data from 2 dimenssion object using loop 
//total 
s = 0
for(let r=0;r<a.length;r++){

    for(let c =0; c<a[r].length;c++){
        //console.log(a[r][c])   // 00   01   02    , 10  11 12 
        s += a[r][c]
    }
}
console.log(`total is `,s)

