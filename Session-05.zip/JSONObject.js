
var emp ={id:11,name:'nitin',gender:'male'}

//print data type
console.log(typeof emp)

//print all data 
console.log(emp)

//print by key 
console.log(emp.id)
console.log(emp.name)


// 4 rows, 3 cols 
emplist = [{id:11,name:'nitin',gender:'male'},
            {id:1,name:'monika',gender:'female'},
            {id:110,name:'amit',gender:'male'},
            {id:21,name:'rahul',gender:'male'}]

console.log(emplist)



console.log(emplist[1]) //read 2nd row
console.log(emplist[1].name)

//fitler 
o = emplist.filter(x=> x.gender =='male')
console.log(o)

//sorting  localeCompare(): string compare
emp =  emplist.sort((a,b)=> a.name.localeCompare(b.name))
console.log(emp)








