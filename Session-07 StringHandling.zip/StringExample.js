///String example
var str ="this is test string.we are learning nodejs"

//get length
console.log(str.length) //count of char indulding space

//convert to upper case
console.log(str.toUpperCase())

//convert to lower case 
console.log(str.toLowerCase())

//trim : remove leading space from left and right 
 str ="   this is test string.we are learning nodejs   "

ns = str.trim()
console.log(str)
console.log(ns)

ns = str.trimLeft()
console.log(ns)
ns = str.trimRight()
console.log(ns)


//repeat
console.log(ns.repeat(3))


//find the char/word position 
pos = ns.indexOf("is")
console.log(pos)

//last position
pos = ns.lastIndexOf("is")
console.log(pos)

//slice:substring
str ="this is test string.we are learning nodejs"
console.log(str.slice(10,15)) //from 10 to 14th index

//subsring
ns =str.substring(3,10)
console.log(ns)

ns =str.substring(str.length-5) //last 5 chars
console.log(ns)

//replace
//str =str.replace('i','are')
console.log(str.replace('i','are')) //replace first i 

//split : break the string by given seperator 
o = str.split(' ')
console.log(o)

//break : char by char
o = str.split('')
console.log(o)

//get the count of i 
c = o.filter(x => x=='i').length
console.log(c)

str ="this is test string.we are learning nodejs"
console.log( str.search("i"))



if(str.endsWith("js")){
    console.log('ending with js')
}else{

    console.log('not ending with js')
}

//startswith
if(str.startsWith("js")){
    console.log('start with js')
}else{

    console.log('not start with js')
}


//compare anywhere/ contains
if(str.includes("js")){
    console.log(' js match')
}else{

    console.log('js not match')
}


//concat 
s1="this"
s2="is"
s= s1.concat(" ",s2)
console.log(s)


// string compare

s1= "a"
s2 ="A"
console.log(s1.localeCompare(s2)) //lower case compare 
console.log(s1.toLocaleUpperCase())






