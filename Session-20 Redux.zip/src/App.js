import React from 'react';
import AllPost from './components/AllPost';
import PostForm from './components/PostForm';


function App() {
  return (
    <div>

        <PostForm/>
        <AllPost/>
        
    </div>
  );
}

export default App;
