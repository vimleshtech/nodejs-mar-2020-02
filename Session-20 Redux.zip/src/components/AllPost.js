import React,{Component} from 'react';
import { connect, connectAdvanced } from 'react-redux';

class AllPost extends Component{
    constructor(){
        super();

    }
    render(){

        return(<div>
            <h1> AllForm </h1>
            {console.log(this.props.posts)}
            
            {this.props.posts.map((row,i)=>

            <p> {row.title} | {row.message}</p>
            )}


            </div>)
    }
}

const mapStateToProps = (state) => {
    return {
        posts: state
    }
}


export default  connect(mapStateToProps)(AllPost);