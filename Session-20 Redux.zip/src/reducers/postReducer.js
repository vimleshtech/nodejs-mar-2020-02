//state = []   default value is empty array , action : add, get 

//state: store data 
//postReducer : action 

const postReducer = (state = [], action) => {

    switch(action.type) {

      case 'ADD':

        return state.concat([action.data]);

      default:

        return state;

    }
  }
  export default postReducer;
