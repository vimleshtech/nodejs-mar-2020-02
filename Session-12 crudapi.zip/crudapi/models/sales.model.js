//const mongoose  = require("mongoose");
const mysql = require("mysql");
const Schema = mysql.Schema;


let CustomerSchema = new Schema({

    name:{type: String, required: true, max: 100},
    email:{type: String, required: false, max: 100},
    gender:{type: String, required: false, max: 100},
    country:{type: String, required: false, max: 100},

});

//export the model
module.exports = mysql.model('Customer',CustomerSchema);


