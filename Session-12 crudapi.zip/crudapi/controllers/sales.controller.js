//const Sales = require("../models/sales.model");

//Simple version, without validation or sanitation 

exports.test = function(req,res){

        res.send('Greetings from the Sales  Test controller!');
};