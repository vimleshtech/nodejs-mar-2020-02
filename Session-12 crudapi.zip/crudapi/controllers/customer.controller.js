//const Customer = require("../models/customer.model");
const mysql= require('mysql');


const con = mysql.createConnection({
        host:'localhost',
        database:'hrms',
        user:'root',
        password:'root'
});

//Simple version, without validation or sanitation 
module.exports ={
        
        test:function(req,res){

                        res.send('Greetings from the Customer Test controller!');

        },
        
        newCustomer:function(req,res){
                
                        var cid=101;
                        var cname='Rahul';
                        
                        con.query(`insert into customer(cid,c_name) values(${cid},'${cname}');`,(err,data)=>{
                                if(err)
                                        res.json( {code:401,msg:err})
                                else 
                                        res.json(  {code:200,data:data})

                        });

                       // res.send('Greetings from the Customer Test controller!');
                       //res.json( {code:200,msg:'success'});

        },
                        
        updateCustomer:function(req,res){
                
                        res.send('Greetings from the Customer Test controller!');
        },
        deleteCustomer:function(req,res){
                
                        
                        var cid=101;        
                        con.query(`delete from  customer where cid= ${cid};`,(err,data)=>{
                                if(err)
                                        return {code:401,msg:err}
                                else 
                                        return {code:200,data:data}

                        });

                        res.send('Greetings from the Customer Test controller!');


        },
        searchCustomer:function(req,res){
                
                var cid=101;        
                con.query(`select * from customer where cid= ${cid};`,(err,data)=>{
                        if(err)
                                return {code:401,msg:err}
                        else 
                                return {code:200,data:data}

                });


                        res.send('Greetings from the Customer Test controller!');
        },
        allCustomer:function(req,res){
                
                con.query(`select * from customer;`,(err,data)=>{
                        if(err)
                                return {code:401,msg:err}
                        else 
                                return {code:200,data:data}

                });


                        res.send('Greetings from the Customer Test controller!');
        }

}