
//import required module
const express = require("express");

const bodyParser = require("body-parser");
const router = require("./routes/route.module");

const customer_controller = require("./controllers/customer.controller");

//initialize our express app
const app = express();

app.use(router);

/*app.get('',(req,res)=>{

        res.json({code:200,msg:'success'});
});

app.get('/addcustomer',(req,res)=>{

    //customer_controller.newCustomer(req,res);
    res.json({code:200,msg:'addcustomer'})

});
*/
//initialize the port
let port = 3010;
app.listen(port,()=>{
    console.log("Server is up and running on port number "+port);
});




