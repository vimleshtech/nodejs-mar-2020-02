//import library 
// till ES5 : require
// ES>5     : import 

import React from 'react';

//extends : inherit the one class features to another class 
class   App extends React.Component{           //is wrapper of data member and method/function 


  //constructor     //is function which invoke automatically 
  constructor(){
    super();   //invoke to parent class   

  }


  //create method 
  add=()=>{

    //console.log('you have clicked on button');
    //alert('you have clicked..');

    var n = this.refs.name.value;
    var e = this.refs.email.value;

    console.log('your data is ',n,' ',e);

  }

  render(){  //return the template 
    return (<div> 

              <h1> First App  </h1>
              Interploation = {4+5-55676333}


              <h2> User Form </h2>
              <p>  Name : <input type="text"  ref="name"/> </p>
              <p> Email : <input type="text" ref="email"/>  </p>
              <p>  <input type="button" value="Add User" onClick={this.add} /> </p>

              

      </div>)
  }
}

//export 
export default App;

