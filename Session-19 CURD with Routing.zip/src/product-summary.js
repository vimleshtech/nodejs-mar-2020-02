import React,{Component} from 'react';


class ProductSummary extends Component{

    constructor(){
            super();
    }

    render(){

        return(<div>
                    <h1> Product Summary </h1>
                    <h3>  Total Count : {this.props.total_count} | 
                    Selected Count  : {this.props.selected_count} | 
                    Unselected Count : {this.props.unselected_count} </h3>
            </div>)
    }

}
export default ProductSummary;