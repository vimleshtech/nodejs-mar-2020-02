import React,{Component} from 'react';

/*
API: library or service which can be accessed over the internet to post or get data 
====================================================================================
Promise : is javascript library to consume the API

	fetch(url)
	.then(res...)
	.then(...)
https://jsonplaceholder.typicode.com/
				todos
				users
				posts		
fetch("https://jsonplaceholder.typicode.com/todos")
.then(res=>res.json())
.then(out=>console.log(out))
*/


class ApiCall extends Component{


    constructor(){
        super();
        this.state ={data:[]};


    }


  componentWillMount(){
    console.log('now, complement will create, means render function will call ');
    fetch("https://jsonplaceholder.typicode.com/todos")
    .then(res=>res.json())
    .then(out=>{

        this.setState({data:out})
    });

  }

    getData =()=>{

        fetch("https://jsonplaceholder.typicode.com/todos")
        .then(res=>res.json())
        .then(out=>{

            this.setState({data:out})
        });
    }

    search=()=>{

            var txt = this.refs.search.value;
            console.log(txt);
            if(txt.length>2){

                    console.log('in len');
                
                        fetch("https://jsonplaceholder.typicode.com/todos")
                        .then(res=>res.json())
                        .then(out=>{

                            out = out.filter(row=>row.title.indexOf(txt)>-1)
                            this.setState({data:out})
                        });
                        
            }
    }
    render(){

            return(<div>


                    <div>
                            <input type="text" ref="search" onKeyUp={this.search} />
                    </div>

                    <input type="button" value="API CALL" onClick={this.getData} />
                    
                        {this.state.data.map((row,i)=><p>
                                    {row.id} | {row.title} 
                            </p>)}
                </div>)
    }

}

export default ApiCall;