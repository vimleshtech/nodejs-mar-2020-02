import React,{Component} from 'react';

class App extends Component{

  constructor(){
    
    super();
    this.state ={
        data:[],
        ind:-1
    }
  }


  productAdd=()=>{

    var pname = this.refs.pname.value;
    var price = this.refs.price.value;
    var qty = this.refs.qty.value;


    //add data in state object
    var data = this.state.data;
    data.push({pname:pname,price:price,qty:qty,isSelected:false});
    //store the data to state
    this.setState({data:data});


    //reset value / clean the form
    this.refs.pname.value="";
    this.refs.price.value="";
    this.refs.qty.value="";


    //print the data 
    console.log(this.state.data);
    this.summary();
  }

  delRow=(ind) =>{
    //alert(ind);

    var data = this.state.data;
    data.splice(ind,1); //remove the row 

    this.setState({data:data});

  }

  editRow=(ind) =>{
    //alert(ind);

    var data = this.state.data;
   
    this.refs.pname.value=data[ind].pname;
    this.refs.price.value=data[ind].price;
    this.refs.qty.value=data[ind].qty;

    //store index in state
    this.setState({ind});

  }
  upProduct=()=>{

    var ind  = this.state.ind;
    var data = this.state.data;

    var pname = this.refs.pname.value;
    var price = this.refs.price.value;
    var qty = this.refs.qty.value;



    data[ind].pname = pname;
    data[ind].price=price;
    data[ind].qty =qty;

    this.setState({data:data});


    //reset value / clean the form
    this.refs.pname.value="";
    this.refs.price.value="";
    this.refs.qty.value="";


  }
  
  render(){

  
    return(

      <div>
  
            <h1> Product Form </h1>
            <p>
              Product Name  <input type="text" ref="pname" />
            </p>
            <p>
              Price <input type="text" ref="price"/>
              </p>
            <p>
              Quantity <input type="text" ref="qty" />
            </p>
          <p>
            <input type="button" value="Add Product" onClick={this.productAdd} />
            <input type="button" value="Update Product" onClick={this.upProduct} />

          </p>

          <div>
              {this.state.data.map((row,i)=><p>
                
                      {row.pname} | {row.price}  | {row.qty} 

                      <input type="button" value="Del" onClick={()=> this.delRow(i)} />

                      <input type="button" value="Edit"  onClick={()=>this.editRow(i)}/>

                </p>)}
          </div>

      </div>

    );


    
  }

}

export default App;
