
import React from 'react';

class App extends React.Component{

  constructor(){
    super();
  }
  render(){

      return(<div>
        
            <h1> My First App </h1>
        </div>)
  }


}
export default App; 